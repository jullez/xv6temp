#include "types.h"
#include "stat.h"
#include "user.h"

int convert(char *str){
	int result=0;
	int i=0;

	for(; str[i] != '\0';i++){
		if(str[i]<'0' ||str[i]>'9')
			return 0;
		result=result*10+(str[i]-'0');
	}
	return result;

}
int main(int argc, char *argv[]){
	int pid, prio;
	pid= atoi(argv[1]);
	prio=atoi(argv[2]);

	set(pid,prio);
	exit();
}
