#include "types.h"
#include "stat.h"
#include "user.h"

int main(){
	printf(1,"pid\t\tname\t\tstate\t\tparent\t\tpriority\n");
	pstate();
	exit();
}
